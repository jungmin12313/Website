import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, Minus, Plus } from 'lucide-react'
import './Navbar.css'

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [fontSize, setFontSize] = useState(100)
  const location = useLocation()

  const changeFontSize = (delta: number) => {
    const next = Math.min(140, Math.max(80, fontSize + delta))
    setFontSize(next)
    document.documentElement.style.fontSize = `${next}%`
  }

  const navLinks = [
    { to: '/about', label: '소개' },
    { to: '/maps', label: '무장애지도' },
    { to: '/calendar', label: '축제 캘린더' },
    { to: '/report', label: '신고센터' },
  ]

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <div className="navbar-left">
          <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <Link to="/" className="logo-link">
            <img src="/logo.png" alt="내일" className="logo-img" />
          </Link>
        </div>

        <div className="font-control">
          <span>화면크기</span>
          <button onClick={() => changeFontSize(-10)}><Minus size={14} /></button>
          <span className="divider">|</span>
          <button onClick={() => changeFontSize(10)}><Plus size={14} /></button>
        </div>

        <div className="navbar-links">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`nav-link ${location.pathname.startsWith(link.to) ? 'active' : ''}`}
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>

      {menuOpen && (
        <div className="mobile-menu">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className="mobile-link"
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  )
}
