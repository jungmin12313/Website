import { useState, useRef, useEffect } from 'react'
import { Plus, Trash2, Save, Upload, X } from 'lucide-react'
import type { Hotspot, Festival } from '../types'
import './Admin.css'

export default function Admin() {
  const [festivals, setFestivals] = useState<Festival[]>([])
  const [selectedId, setSelectedId] = useState<string>('')
  const [festival, setFestival] = useState<Festival | null>(null)
  const [hotspots, setHotspots] = useState<Hotspot[]>([])
  const [mapSrc, setMapSrc] = useState<string>('')
  const [adding, setAdding] = useState(false)
  const [editHs, setEditHs] = useState<Hotspot | null>(null)
  const [, setPendingPos] = useState<{x: number, y: number} | null>(null)
  const mapRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetch('/data/festivals.json')
      .then(r => r.json())
      .then((data: Festival[]) => setFestivals(data))
  }, [])

  const loadFestival = (id: string) => {
    const f = festivals.find(f => f.id === id)
    if (!f) return
    setFestival(f)
    setHotspots(f.hotspots || [])
    setMapSrc(f.mapImage || '')
    setSelectedId(id)
  }

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!adding) return
    const rect = mapRef.current!.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    const newHs: Hotspot = {
      id: `hs-${Date.now()}`,
      x: Math.round(x * 100) / 100,
      y: Math.round(y * 100) / 100,
      label: '',
      description: [],
      pictogramIds: [],
      photos: [],
    }
    setPendingPos({ x, y })
    setEditHs(newHs)
    setAdding(false)
  }

  const handleMapUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const url = URL.createObjectURL(file)
    setMapSrc(url)
  }

  const saveHotspot = (hs: Hotspot) => {
    setHotspots(prev => {
      const exists = prev.find(h => h.id === hs.id)
      return exists ? prev.map(h => h.id === hs.id ? hs : h) : [...prev, hs]
    })
    setEditHs(null)
    setPendingPos(null)
  }

  const deleteHotspot = (id: string) => {
    setHotspots(prev => prev.filter(h => h.id !== id))
  }

  const exportJSON = () => {
    if (!festival) return
    const updated = { ...festival, hotspots, mapImage: mapSrc }
    const blob = new Blob([JSON.stringify(updated, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${festival.id}.json`
    a.click()
  }

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>어드민 — 핫스팟 설정</h1>
        <p className="admin-sub">내일 팀원 전용 페이지입니다.</p>
      </div>

      <div className="admin-body">
        {/* 사이드바 */}
        <div className="admin-sidebar">
          <div className="sidebar-section">
            <label className="sidebar-label">축제 선택</label>
            <select
              value={selectedId}
              onChange={e => loadFestival(e.target.value)}
              className="admin-select"
            >
              <option value="">-- 축제를 선택하세요 --</option>
              {festivals.map(f => (
                <option key={f.id} value={f.id}>{f.name}</option>
              ))}
            </select>
          </div>

          {festival && (
            <>
              <div className="sidebar-section">
                <label className="sidebar-label">지도 이미지 업로드</label>
                <label className="upload-btn">
                  <Upload size={16} />
                  이미지 선택
                  <input type="file" accept="image/*" onChange={handleMapUpload} style={{ display: 'none' }} />
                </label>
                {mapSrc && <p className="upload-hint">지도 이미지가 로드되었습니다.</p>}
              </div>

              <div className="sidebar-section">
                <label className="sidebar-label">핫스팟 목록 ({hotspots.length}개)</label>
                <div className="hs-list">
                  {hotspots.map(hs => (
                    <div key={hs.id} className="hs-item">
                      <button className="hs-name" onClick={() => setEditHs(hs)}>
                        {hs.label || '(이름 없음)'}
                        <span className="hs-pos">({hs.x.toFixed(1)}%, {hs.y.toFixed(1)}%)</span>
                      </button>
                      <button className="hs-delete" onClick={() => deleteHotspot(hs.id)}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                  {hotspots.length === 0 && (
                    <p className="hs-empty">지도를 클릭하여 핫스팟을 추가하세요.</p>
                  )}
                </div>

                <button
                  className={`add-btn ${adding ? 'active' : ''}`}
                  onClick={() => setAdding(!adding)}
                >
                  <Plus size={16} />
                  {adding ? '클릭 취소' : '지도에서 위치 선택'}
                </button>
              </div>

              <button className="export-btn" onClick={exportJSON}>
                <Save size={16} />
                JSON 내보내기
              </button>
            </>
          )}
        </div>

        {/* 지도 영역 */}
        <div className="admin-map-area">
          {adding && (
            <div className="adding-hint">지도에서 핫스팟을 추가할 위치를 클릭하세요</div>
          )}
          <div
            className={`admin-map ${adding ? 'cursor-crosshair' : ''}`}
            ref={mapRef}
            onClick={handleMapClick}
          >
            {mapSrc ? (
              <img src={mapSrc} alt="지도" className="admin-map-img" />
            ) : (
              <div className="admin-map-empty">
                <p>지도 이미지를 업로드해주세요</p>
              </div>
            )}

            {hotspots.map(hs => (
              <button
                key={hs.id}
                className="admin-hotspot"
                style={{ left: `${hs.x}%`, top: `${hs.y}%` }}
                onClick={e => { e.stopPropagation(); setEditHs(hs) }}
                title={hs.label}
              >
                <span className="admin-hs-label">{hs.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 핫스팟 편집 패널 */}
      {editHs && (
        <HotspotEditor
          hotspot={editHs}
          pictograms={festival?.pictograms || []}
          onSave={saveHotspot}
          onClose={() => { setEditHs(null); setPendingPos(null) }}
        />
      )}
    </div>
  )
}

/* ── 핫스팟 편집 폼 ── */
function HotspotEditor({
  hotspot, pictograms, onSave, onClose
}: {
  hotspot: Hotspot
  pictograms: Festival['pictograms']
  onSave: (hs: Hotspot) => void
  onClose: () => void
}) {
  const [hs, setHs] = useState<Hotspot>({ ...hotspot })
  const [descText, setDescText] = useState(hotspot.description.join('\n'))

  const update = (field: keyof Hotspot, val: unknown) => {
    setHs(prev => ({ ...prev, [field]: val }))
  }

  const handleSave = () => {
    onSave({ ...hs, description: descText.split('\n').filter(Boolean) })
  }

  const togglePic = (id: string) => {
    setHs(prev => ({
      ...prev,
      pictogramIds: prev.pictogramIds.includes(id)
        ? prev.pictogramIds.filter(p => p !== id)
        : [...prev.pictogramIds, id]
    }))
  }

  return (
    <div className="editor-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="editor-panel">
        <div className="editor-header">
          <h3>핫스팟 편집</h3>
          <button onClick={onClose}><X size={18} /></button>
        </div>

        <div className="editor-body">
          <label className="editor-label">장소 이름</label>
          <input
            className="editor-input"
            value={hs.label}
            onChange={e => update('label', e.target.value)}
            placeholder="예: 셔틀버스 승강장 및 장애인 주차장"
          />

          <label className="editor-label">설명 (줄바꿈으로 구분)</label>
          <textarea
            className="editor-textarea"
            value={descText}
            onChange={e => setDescText(e.target.value)}
            rows={5}
            placeholder="입구 진입 경사로: 약 5도(1/12)&#10;진입은 가능하나, 자갈로 되어있으므로 활동지원사 필요"
          />

          {pictograms.length > 0 && (
            <>
              <label className="editor-label">픽토그램 선택</label>
              <div className="editor-pics">
                {pictograms.map(p => (
                  <label key={p.id} className={`pic-toggle ${hs.pictogramIds.includes(p.id) ? 'selected' : ''}`}>
                    <input
                      type="checkbox"
                      checked={hs.pictogramIds.includes(p.id)}
                      onChange={() => togglePic(p.id)}
                    />
                    {p.name}
                  </label>
                ))}
              </div>
            </>
          )}

          <label className="editor-label">위치</label>
          <p className="editor-pos">X: {hs.x.toFixed(2)}%　Y: {hs.y.toFixed(2)}%</p>
        </div>

        <div className="editor-footer">
          <button className="editor-cancel" onClick={onClose}>취소</button>
          <button className="editor-save" onClick={handleSave}>
            <Save size={15} /> 저장
          </button>
        </div>
      </div>
    </div>
  )
}
